<?php
/** @noinspection PhpIncludeInspection */
require_once __DIR__.'/vendor/autoload.php' ;

require_once __DIR__.'/Commands/DependCommand.php';